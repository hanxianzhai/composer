<?php

require_once(__DIR__ . DIRECTORY_SEPARATOR . 'qcloudcos' . DIRECTORY_SEPARATOR . 'auth.php');
require_once(__DIR__ . DIRECTORY_SEPARATOR . 'qcloudcos' . DIRECTORY_SEPARATOR . 'conf.php');
require_once(__DIR__ . DIRECTORY_SEPARATOR . 'qcloudcos' . DIRECTORY_SEPARATOR . 'cosapi.php');
require_once(__DIR__ . DIRECTORY_SEPARATOR . 'qcloudcos' . DIRECTORY_SEPARATOR . 'http_client.php');
require_once(__DIR__ . DIRECTORY_SEPARATOR . 'qcloudcos' . DIRECTORY_SEPARATOR . 'slice_uploading.php');
