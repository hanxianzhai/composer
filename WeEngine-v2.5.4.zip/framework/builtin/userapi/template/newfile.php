<?php

function echoi() {
}